var searchData=
[
  ['addstream_0',['addStream',['../class_video_output.html#a81ce3a3302ceeb3b3a8fe682faf813c9',1,'VideoOutput']]],
  ['allocateframebuffer_1',['allocateFrameBuffer',['../class_video_output.html#aa516ddfd677829253ac63edf93ebe050',1,'VideoOutput']]]
];
