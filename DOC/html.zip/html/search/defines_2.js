var searchData=
[
  ['window_5fframe_5fh_0',['WINDOW_FRAME_H',['../image__provider_8cpp.html#a1428bf26b78453dea106b9e6ff61462a',1,'image_provider.cpp']]],
  ['window_5fframe_5fw_1',['WINDOW_FRAME_W',['../image__provider_8cpp.html#a5b30684089c70a5d796ba9349cf8a9a2',1,'image_provider.cpp']]]
];
