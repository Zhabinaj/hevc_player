var searchData=
[
  ['camera_0',['camera',['../struct_data__sei__str.html#a90d2c0e8616c49ce30f100da38bb934e',1,'Data_sei_str']]],
  ['camera_5f_1',['camera_',['../class_session.html#a0775bcdff69716c55ff78e2e3f051d7f',1,'Session']]],
  ['channels_5f_2',['channels_',['../class_video_output.html#ae43b3a7b5c1416b0c6f3d518b6324767',1,'VideoOutput']]],
  ['closest_5fkey_5fframe_5f_3',['closest_key_frame_',['../class_player.html#a8b16ee5c90f24af787be3b82dbf2cbf7',1,'Player']]],
  ['codec_5fcontext_5f_4',['codec_context_',['../struct_video_output_1_1_output_stream.html#a9d525017a65b6e4c3fb29f08317434de',1,'VideoOutput::OutputStream']]]
];
