var searchData=
[
  ['zip_20and_20run_20hevc_5fpayer_20exe_0',['2: For using app on windows download hevc_player_win.zip and run hevc_payer.exe',['../index.html#step2',1,'']]]
];
