var searchData=
[
  ['next_5fpts_5f_0',['next_pts_',['../struct_video_output_1_1_output_stream.html#a0d0d631d908255e5e86fcffff749d3b1',1,'VideoOutput::OutputStream']]],
  ['nextframeclicked_1',['nextFrameClicked',['../class_session.html#ae57d757fd732313b43e3623eb127f800',1,'Session']]]
];
