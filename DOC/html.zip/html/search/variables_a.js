var searchData=
[
  ['next_5fframe_5fclicked_5f_0',['next_frame_clicked_',['../class_session.html#adff9727e384c0d8d0494a6ca83e31df8',1,'Session']]],
  ['next_5fpts_5f_1',['next_pts_',['../struct_video_output_1_1_output_stream.html#a0d0d631d908255e5e86fcffff749d3b1',1,'VideoOutput::OutputStream']]]
];
