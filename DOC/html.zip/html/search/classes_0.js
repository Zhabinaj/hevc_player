var searchData=
[
  ['camera_5fstruct_0',['camera_struct',['../structcamera__struct.html',1,'']]]
];
