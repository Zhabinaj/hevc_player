var searchData=
[
  ['pause_0',['PAUSE',['../class_session.html#aba254648d93d617e227610def85014ada291554596c183e837f0a6bec3767c891',1,'Session']]],
  ['play_1',['PLAY',['../class_session.html#aba254648d93d617e227610def85014ada6a216efc529825c60a4a4c0bc99ad77f',1,'Session']]]
];
