var searchData=
[
  ['totalframeschanged_0',['totalFramesChanged',['../class_session.html#adcfdd691b9a08bd10594c9605246f9d5',1,'Session']]]
];
