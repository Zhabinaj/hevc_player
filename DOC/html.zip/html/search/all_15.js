var searchData=
[
  ['x_0',['x',['../structstrob__struct.html#a5c03c1dfb11e77d7a13429e4b6dddc4d',1,'strob_struct']]]
];
